#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main() {
    int fd1 = 0;
    int fd2 = 0;
    char *connect = {"CONNECT"};
    char *success = {"SUCCESS"};
    char *error = {"ERROR"};
    char *pong = {"PONG"};
    int variant = 27635;
    int seven = 7;
    int four = 4;
    int five = 5;
    int len = 0;
    key_t key = 12005;
    if (mkfifo("RESP_PIPE_27635", 0644) < 0) {
        printf("ERROR\n");
        printf("cannot create the response pipe\n");
        exit(1);
    }
    fd1 = open("RESP_PIPE_27635", O_RDWR);
    fd2 = open("REQ_PIPE_27635", O_RDWR);
    if (fd2<0) {
        printf("ERROR\n");
        printf("cannot open the request pipe\n");
        exit(1);
    }
    else {
        printf("SUCCESS\n");
    }
    write(fd1, &seven, 1);
    write(fd1, connect, seven);
    while (1) {
        char buf[100];
        read(fd2, &len, 1);
        read(fd2, buf, len);
        if (strcmp(buf, "PING") == 0) {
            write(fd1, &len, 1);
            write(fd1, buf, len);
            write(fd1, &four, 1);
            write(fd1, pong, four);
            write(fd1, &variant, 5);
        }
        if (strcmp("CREATE_SHM", buf) == 0) {
            unsigned int p1 = 0;
            int shmem = 0;
            read(fd2, &p1, 7);
            shmem = shmget(key, p1, IPC_CREAT|IPC_EXCL|0664);
            void* ptr = (int*)shmat(shmem, (void*)0, 0);
            if (shmem == -1) {
                write(fd1, &len, 1);
                write(fd1, buf, len);
                write(fd1, &five, 1);
                write(fd1, error, five);
            }
            if (ptr == (int*)(-1)){
                write(fd1, &len, 1);
                write(fd1, buf, len);
                write(fd1, &five, 1);
                write(fd1, error, five);
            }
            else {
                write(fd1, &len, 1);
                write(fd1, buf, len);
                write(fd1, &seven, 1);
                write(fd1, success, seven);
            }
            shmdt(ptr);
        }
        if (strcmp(buf, "EXIT") == 0) {
            close(fd1);
            close(fd2);
            unlink("RESP_PIPE_27635");
            exit(0);
        }
        else
            exit(1);

    }
   // close(fd1);
   // close(fd2);
    //unlink("RESP_PIPE_27635");
    return 0;
}
